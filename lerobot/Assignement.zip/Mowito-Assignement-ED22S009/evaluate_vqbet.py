"""
VQ-BeT evaluation script based on LeRobot example 2
"""
from pathlib import Path
import gym_pusht
import gymnasium as gym
import imageio
import numpy as np
import torch
from lerobot.policies.vqbet.modeling_vqbet import VQBeTPolicy

# Configuration
output_directory = Path("outputs/eval/vqbet_pusht/run1")
output_directory.mkdir(parents=True, exist_ok=True)

device = "cuda" if torch.cuda.is_available() else "cpu"
pretrained_policy_path = "checkpoints/vqbet_pusht"
n_episodes = 50

print(f"Loading VQ-BeT policy from {pretrained_policy_path}...")
policy = VQBeTPolicy.from_pretrained(pretrained_policy_path)
policy.to(device)
print(f"Policy loaded on {device}")

# Create environment
env = gym.make("gym_pusht/PushT-v0", obs_type="pixels_agent_pos", max_episode_steps=300)

print(f"\nRunning {n_episodes} evaluation episodes...")
all_results = []

for episode in range(n_episodes):
    policy.reset()
    numpy_observation, info = env.reset(seed=42 + episode)
    
    rewards = []
    frames = []
    frames.append(env.render())
    
    step = 0
    done = False
    
    while not done:
        # Prepare observation
        state = torch.from_numpy(numpy_observation["agent_pos"]).to(torch.float32)
        image = torch.from_numpy(numpy_observation["pixels"]).to(torch.float32) / 255
        image = image.permute(2, 0, 1)
        
        state = state.to(device, non_blocking=True).unsqueeze(0)
        image = image.to(device, non_blocking=True).unsqueeze(0)
        
        observation = {
            "observation.state": state,
            "observation.image": image,
        }
        
        # Get action
        with torch.inference_mode():
            action = policy.select_action(observation)
        
        numpy_action = action.squeeze(0).to("cpu").numpy()
        
        # Step environment
        numpy_observation, reward, terminated, truncated, info = env.step(numpy_action)
        
        rewards.append(reward)
        frames.append(env.render())
        
        done = terminated | truncated
        step += 1
    
    success = terminated
    total_reward = sum(rewards)
    
    all_results.append({
        'episode': episode,
        'success': bool(success),
        'reward': float(total_reward),
        'steps': step
    })
    
    # Save video for first 5 episodes
    if episode < 5:
        fps = env.metadata["render_fps"]
        video_path = output_directory / f"episode_{episode}.mp4"
        imageio.mimsave(str(video_path), np.stack(frames), fps=fps)
    
    if (episode + 1) % 10 == 0:
        success_rate = sum(r['success'] for r in all_results) / len(all_results)
        avg_reward = sum(r['reward'] for r in all_results) / len(all_results)
        print(f"Episodes {episode + 1}/{n_episodes} - Success: {success_rate:.1%}, Avg Reward: {avg_reward:.2f}")

# Final results
success_rate = sum(r['success'] for r in all_results) / len(all_results)
avg_reward = sum(r['reward'] for r in all_results) / len(all_results)
avg_steps = sum(r['steps'] for r in all_results) / len(all_results)

print(f"\n{'='*60}")
print("EVALUATION RESULTS")
print(f"{'='*60}")
print(f"Episodes: {n_episodes}")
print(f"Success Rate: {success_rate:.2%}")
print(f"Average Reward: {avg_reward:.2f}")
print(f"Average Steps: {avg_steps:.1f}")
print(f"{'='*60}")

# Save results
import json
with open(output_directory / "eval_info.json", 'w') as f:
    json.dump({
        'summary': {
            'n_episodes': n_episodes,
            'success_rate': success_rate,
            'avg_reward': avg_reward,
            'avg_steps': avg_steps
        },
        'episodes': all_results
    }, f, indent=2)

print(f"\nResults saved to {output_directory}")
print(f"Videos saved for first 5 episodes")
