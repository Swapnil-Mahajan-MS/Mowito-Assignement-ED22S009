#!/usr/bin/env python3
"""
Robust Euler <-> Quaternion Conversion Script

MATHEMATICAL BACKGROUND:
========================
Euler Angles:
- Represent 3D orientation using three sequential rotations
- Convention: Tait-Bryan ZYX (yaw-pitch-roll)
- Rotation order: R = Rz(yaw) * Ry(pitch) * Rx(roll)
- Roll (φ): Rotation around X-axis [-180°, 180°]
- Pitch (θ): Rotation around Y-axis [-90°, 90°]
- Yaw (ψ): Rotation around Z-axis [-180°, 180°]

Quaternions:
- Four-dimensional representation: q = w + xi + yj + zk
- Format: (x, y, z, w) where w is the scalar part
- Unit quaternion: ||q|| = √(x² + y² + z² + w²) = 1
- Advantages: No gimbal lock, smooth interpolation, compact

Edge Cases Handled:
- Gimbal lock (pitch = ±90°)
- Near-zero quaternions
- Denormalized quaternions
- Numerical precision errors
- Invalid input values
"""

import math
import argparse
import sys
from typing import Tuple, Optional
from dataclasses import dataclass


# ============================================================================
# Constants and Configuration
# ============================================================================

EPSILON = 1e-10  # Numerical tolerance for floating-point comparisons
NORMALIZATION_THRESHOLD = 1e-6  # Minimum norm for valid quaternion


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class EulerAngles:
    """Euler angles in Tait-Bryan ZYX convention."""
    roll: float   # Rotation around X-axis
    pitch: float  # Rotation around Y-axis
    yaw: float    # Rotation around Z-axis
    
    def __post_init__(self):
        """Validate Euler angles are within reasonable ranges."""
        # Note: We don't strictly enforce ranges as wrapping handles this
        pass
    
    def __str__(self):
        return f"Euler(roll={self.roll:.6f}°, pitch={self.pitch:.6f}°, yaw={self.yaw:.6f}°)"


@dataclass
class Quaternion:
    """Quaternion representation (x, y, z, w)."""
    x: float
    y: float
    z: float
    w: float
    
    def norm(self) -> float:
        """Calculate quaternion norm (magnitude)."""
        return math.sqrt(self.x**2 + self.y**2 + self.z**2 + self.w**2)
    
    def is_valid(self) -> bool:
        """Check if quaternion has valid norm."""
        return self.norm() > NORMALIZATION_THRESHOLD
    
    def __str__(self):
        return f"Quat(x={self.x:.6f}, y={self.y:.6f}, z={self.z:.6f}, w={self.w:.6f})"


# ============================================================================
# Core Conversion Functions
# ============================================================================

def normalize_quaternion(quat: Quaternion) -> Quaternion:
    """
    Normalize quaternion to unit length.
    
    Args:
        quat: Input quaternion
        
    Returns:
        Normalized quaternion
        
    Raises:
        ValueError: If quaternion has near-zero norm
    """
    norm = quat.norm()
    
    if norm < NORMALIZATION_THRESHOLD:
        raise ValueError(
            f"Cannot normalize quaternion with near-zero norm: {norm:.2e}. "
            f"Input: {quat}"
        )
    
    return Quaternion(
        x=quat.x / norm,
        y=quat.y / norm,
        z=quat.z / norm,
        w=quat.w / norm
    )


def euler_to_quaternion(
    euler: EulerAngles,
    degrees: bool = True,
    normalize: bool = True
) -> Quaternion:
    """
    Convert Euler angles to quaternion.
    
    Convention: Tait-Bryan ZYX (yaw-pitch-roll)
    R = Rz(yaw) * Ry(pitch) * Rx(roll)
    
    Args:
        euler: Euler angles (roll, pitch, yaw)
        degrees: If True, input angles are in degrees
        normalize: If True, normalize output quaternion
        
    Returns:
        Quaternion representation
        
    Edge cases handled:
    - Large angle values (automatically wrapped)
    - Gimbal lock conditions (pitch = ±90°)
    """
    # Convert to radians if needed
    if degrees:
        roll = math.radians(euler.roll)
        pitch = math.radians(euler.pitch)
        yaw = math.radians(euler.yaw)
    else:
        roll = euler.roll
        pitch = euler.pitch
        yaw = euler.yaw
    
    # Compute half angles
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    
    # ZYX rotation order formula
    # Derived from q = qz * qy * qx
    quat = Quaternion(
        x=sr * cp * cy - cr * sp * sy,
        y=cr * sp * cy + sr * cp * sy,
        z=cr * cp * sy - sr * sp * cy,
        w=cr * cp * cy + sr * sp * sy
    )
    
    # Normalize to handle numerical errors
    if normalize:
        quat = normalize_quaternion(quat)
    
    return quat


def quaternion_to_euler(
    quat: Quaternion,
    degrees: bool = True,
    normalize: bool = True
) -> EulerAngles:
    """
    Convert quaternion to Euler angles.
    
    Convention: Tait-Bryan ZYX (yaw-pitch-roll)
    
    Args:
        quat: Input quaternion (x, y, z, w)
        degrees: If True, output angles in degrees
        normalize: If True, normalize input quaternion first
        
    Returns:
        Euler angles (roll, pitch, yaw)
        
    Edge cases handled:
    - Gimbal lock (pitch = ±90°)
    - Denormalized quaternions
    - Numerical precision near singularities
    """
    # Normalize quaternion to be safe
    if normalize:
        quat = normalize_quaternion(quat)
    
    x, y, z, w = quat.x, quat.y, quat.z, quat.w
    
    # Roll (X-axis rotation)
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    
    # Pitch (Y-axis rotation) - Handle gimbal lock
    sinp = 2.0 * (w * y - z * x)
    
    # Clamp to [-1, 1] to handle numerical errors
    # This prevents math domain errors in asin
    if sinp >= 1.0:
        pitch = math.pi / 2.0  # 90 degrees (gimbal lock)
    elif sinp <= -1.0:
        pitch = -math.pi / 2.0  # -90 degrees (gimbal lock)
    else:
        pitch = math.asin(sinp)
    
    # Yaw (Z-axis rotation)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    
    # Convert to degrees if requested
    if degrees:
        roll = math.degrees(roll)
        pitch = math.degrees(pitch)
        yaw = math.degrees(yaw)
    
    return EulerAngles(roll=roll, pitch=pitch, yaw=yaw)


# ============================================================================
# Utility Functions
# ============================================================================

def angle_wrap_180(angle_deg: float) -> float:
    """Wrap angle to [-180, 180] degrees."""
    angle_deg = angle_deg % 360.0
    if angle_deg > 180.0:
        angle_deg -= 360.0
    return angle_deg


def quaternion_multiply(q1: Quaternion, q2: Quaternion) -> Quaternion:
    """
    Multiply two quaternions: result = q1 * q2
    Useful for composing rotations.
    """
    return Quaternion(
        x=q1.w * q2.x + q1.x * q2.w + q1.y * q2.z - q1.z * q2.y,
        y=q1.w * q2.y - q1.x * q2.z + q1.y * q2.w + q1.z * q2.x,
        z=q1.w * q2.z + q1.x * q2.y - q1.y * q2.x + q1.z * q2.w,
        w=q1.w * q2.w - q1.x * q2.x - q1.y * q2.y - q1.z * q2.z
    )


def quaternion_conjugate(quat: Quaternion) -> Quaternion:
    """Get quaternion conjugate (inverse for unit quaternions)."""
    return Quaternion(x=-quat.x, y=-quat.y, z=-quat.z, w=quat.w)


def quaternion_slerp(q1: Quaternion, q2: Quaternion, t: float) -> Quaternion:
    """
    Spherical linear interpolation between two quaternions.
    
    Args:
        q1: Start quaternion
        q2: End quaternion
        t: Interpolation parameter [0, 1]
    """
    # Normalize inputs
    q1 = normalize_quaternion(q1)
    q2 = normalize_quaternion(q2)
    
    # Compute dot product
    dot = q1.x * q2.x + q1.y * q2.y + q1.z * q2.z + q1.w * q2.w
    
    # If negative dot product, negate q2 to take shorter path
    if dot < 0.0:
        q2 = Quaternion(x=-q2.x, y=-q2.y, z=-q2.z, w=-q2.w)
        dot = -dot
    
    # If quaternions are very close, use linear interpolation
    if dot > 0.9995:
        result = Quaternion(
            x=q1.x + t * (q2.x - q1.x),
            y=q1.y + t * (q2.y - q1.y),
            z=q1.z + t * (q2.z - q1.z),
            w=q1.w + t * (q2.w - q1.w)
        )
        return normalize_quaternion(result)
    
    # Standard SLERP
    theta_0 = math.acos(dot)
    theta = theta_0 * t
    sin_theta = math.sin(theta)
    sin_theta_0 = math.sin(theta_0)
    
    s1 = math.cos(theta) - dot * sin_theta / sin_theta_0
    s2 = sin_theta / sin_theta_0
    
    return Quaternion(
        x=s1 * q1.x + s2 * q2.x,
        y=s1 * q1.y + s2 * q2.y,
        z=s1 * q1.z + s2 * q2.z,
        w=s1 * q1.w + s2 * q2.w
    )


# ============================================================================
# Testing and Validation
# ============================================================================

def test_conversions():
    """Run comprehensive tests on edge cases."""
    print("=" * 70)
    print("RUNNING EDGE CASE TESTS")
    print("=" * 70)
    
    test_cases = [
        # (name, euler_angles)
        ("Identity (no rotation)", EulerAngles(0, 0, 0)),
        ("Roll only (90°)", EulerAngles(90, 0, 0)),
        ("Pitch only (90°)", EulerAngles(0, 90, 0)),
        ("Yaw only (90°)", EulerAngles(0, 0, 90)),
        ("Gimbal lock (pitch = 90°)", EulerAngles(45, 90, 30)),
        ("Gimbal lock (pitch = -90°)", EulerAngles(45, -90, 30)),
        ("Combined rotation", EulerAngles(45, 30, 60)),
        ("Large angles", EulerAngles(720, 450, 900)),
        ("Negative angles", EulerAngles(-45, -30, -60)),
        ("Small angles", EulerAngles(0.001, 0.001, 0.001)),
    ]
    
    print("\nTest 1: Euler -> Quaternion -> Euler (Round-trip)")
    print("-" * 70)
    
    for name, euler_in in test_cases:
        try:
            # Convert to quaternion
            quat = euler_to_quaternion(euler_in, degrees=True)
            
            # Convert back to euler
            euler_out = quaternion_to_euler(quat, degrees=True)
            
            # Check if quaternion is normalized
            norm = quat.norm()
            norm_check = "✓" if abs(norm - 1.0) < 1e-6 else "✗"
            
            # Calculate error
            error_roll = abs(angle_wrap_180(euler_in.roll) - angle_wrap_180(euler_out.roll))
            error_pitch = abs(angle_wrap_180(euler_in.pitch) - angle_wrap_180(euler_out.pitch))
            error_yaw = abs(angle_wrap_180(euler_in.yaw) - angle_wrap_180(euler_out.yaw))
            max_error = max(error_roll, error_pitch, error_yaw)
            
            status = "PASS" if max_error < 1e-4 else "FAIL"
            
            print(f"\n{name}:")
            print(f"  Input:  {euler_in}")
            print(f"  Quat:   {quat} [norm={norm:.9f} {norm_check}]")
            print(f"  Output: {euler_out}")
            print(f"  Error:  {max_error:.2e}° [{status}]")
            
        except Exception as e:
            print(f"\n{name}: ERROR - {e}")
    
    print("\n" + "=" * 70)
    print("Test 2: Known Quaternion Values")
    print("-" * 70)
    
    known_quats = [
        ("Identity", Quaternion(0, 0, 0, 1), EulerAngles(0, 0, 0)),
        ("90° roll", Quaternion(0.7071, 0, 0, 0.7071), EulerAngles(90, 0, 0)),
        ("90° pitch", Quaternion(0, 0.7071, 0, 0.7071), EulerAngles(0, 90, 0)),
        ("90° yaw", Quaternion(0, 0, 0.7071, 0.7071), EulerAngles(0, 0, 90)),
    ]
    
    for name, quat_in, expected_euler in known_quats:
        euler_out = quaternion_to_euler(quat_in, degrees=True)
        print(f"\n{name}:")
        print(f"  Input:    {quat_in}")
        print(f"  Output:   {euler_out}")
        print(f"  Expected: {expected_euler}")
    
    print("\n" + "=" * 70)
    print("TESTS COMPLETED")
    print("=" * 70)


# ============================================================================
# Command-Line Interface
# ============================================================================

def parse_arguments() -> Optional[argparse.Namespace]:
    """Parse command-line arguments."""
    # Check if running in Jupyter/IPython
    if "ipykernel_launcher" in sys.argv[0] or "IPython" in sys.modules:
        return None
    
    parser = argparse.ArgumentParser(
        description="Convert between Euler angles and quaternions with edge case handling.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Euler to Quaternion
  %(prog)s --mode e2q --roll 45 --pitch 30 --yaw 60
  
  # Quaternion to Euler
  %(prog)s --mode q2e --x 0.5 --y 0.5 --z 0.5 --w 0.5
  
  # Use radians
  %(prog)s --mode e2q --roll 0.785 --pitch 0.524 --yaw 1.047 --radians
  
  # Run tests
  %(prog)s --test
        """
    )
    
    parser.add_argument(
        "--mode",
        choices=["e2q", "q2e"],
        help="Conversion mode: e2q (Euler->Quaternion) or q2e (Quaternion->Euler)"
    )
    
    parser.add_argument(
        "--radians",
        action="store_true",
        help="Use radians instead of degrees (default: degrees)"
    )
    
    # Euler angle inputs
    parser.add_argument("--roll", type=float, help="Roll angle (rotation around X-axis)")
    parser.add_argument("--pitch", type=float, help="Pitch angle (rotation around Y-axis)")
    parser.add_argument("--yaw", type=float, help="Yaw angle (rotation around Z-axis)")
    
    # Quaternion inputs
    parser.add_argument("--x", type=float, help="Quaternion x component")
    parser.add_argument("--y", type=float, help="Quaternion y component")
    parser.add_argument("--z", type=float, help="Quaternion z component")
    parser.add_argument("--w", type=float, help="Quaternion w component")
    
    # Testing mode
    parser.add_argument(
        "--test",
        action="store_true",
        help="Run comprehensive edge case tests"
    )
    
    return parser.parse_args()


def main():
    """Main entry point."""
    args = parse_arguments()
    
    # Jupyter mode
    if args is None:
        print("Running in Jupyter/IPython environment.")
        print("Functions available:")
        print("  - euler_to_quaternion(euler, degrees=True)")
        print("  - quaternion_to_euler(quat, degrees=True)")
        print("  - test_conversions()")
        print("\nRun test_conversions() to see edge case handling.")
        return
    
    # Test mode
    if args.test:
        test_conversions()
        return
    
    # Conversion mode
    if args.mode is None:
        print("Error: --mode is required (use --test to run tests)")
        print("Use --help for usage information")
        sys.exit(1)
    
    use_degrees = not args.radians
    angle_unit = "degrees" if use_degrees else "radians"
    
    try:
        if args.mode == "e2q":
            # Euler to Quaternion
            if args.roll is None or args.pitch is None or args.yaw is None:
                raise ValueError("--roll, --pitch, and --yaw are required for e2q mode")
            
            euler = EulerAngles(args.roll, args.pitch, args.yaw)
            quat = euler_to_quaternion(euler, degrees=use_degrees)
            
            print(f"Input Euler angles ({angle_unit}):")
            print(f"  Roll:  {euler.roll}")
            print(f"  Pitch: {euler.pitch}")
            print(f"  Yaw:   {euler.yaw}")
            print(f"\nOutput Quaternion:")
            print(f"  x: {quat.x:.10f}")
            print(f"  y: {quat.y:.10f}")
            print(f"  z: {quat.z:.10f}")
            print(f"  w: {quat.w:.10f}")
            print(f"  Norm: {quat.norm():.10f}")
            
        elif args.mode == "q2e":
            # Quaternion to Euler
            if args.x is None or args.y is None or args.z is None or args.w is None:
                raise ValueError("--x, --y, --z, and --w are required for q2e mode")
            
            quat = Quaternion(args.x, args.y, args.z, args.w)
            
            if not quat.is_valid():
                print(f"Warning: Input quaternion has very small norm: {quat.norm():.2e}")
                print("Attempting to normalize...")
            
            euler = quaternion_to_euler(quat, degrees=use_degrees)
            
            print(f"Input Quaternion:")
            print(f"  x: {quat.x}")
            print(f"  y: {quat.y}")
            print(f"  z: {quat.z}")
            print(f"  w: {quat.w}")
            print(f"  Norm: {quat.norm():.10f}")
            print(f"\nOutput Euler angles ({angle_unit}):")
            print(f"  Roll:  {euler.roll:.10f}")
            print(f"  Pitch: {euler.pitch:.10f}")
            print(f"  Yaw:   {euler.yaw:.10f}")
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()